
The files in this directory are for examples and refererence.
------------------------------------------------------------

The following files are in the public domain:

	sRGB.icm
	ClayRGB1998.icm
	lab2lab.icm

	Rec709.icm					Standard Rec 709 High Def. Video space
	EBU3213_PAL.icm				PAL TV Standard Def. type colorspace with Rec 709 transfer curve
	SMPTE_RP145_NTSC.icm		NTSC TV Standard Def. type colorspace with Rec 709 transfer curve

The following files are licensed acording to the
GNU AFFERO GENERAL PUBLIC LICENSE Version 3 :-
see the License.txt file for licensing details.


	ccxx.ti1
	CMP_DT_003.cht
	CMP_Digital_Target-3.cht
	CMP_Digital_Target-3.ti2
	CMP_Digital_Target-3.cie
	ColorChecker.cht
	ColorChecker.cie
	ColorChecker.ti2
	ColorCheckerDC.cht
	ColorCheckerSG.cht
	ECI2002.ti2
	ECI2002R.ti2
	FograStrip2.ti1
	FograStrip2.ti2
	FograStrip3.ti1
	FograStrip3.ti2
	Hutchcolor.cht
	LaserSoftDCPro.cht
	QPcard_201.cht
	QPcard_201.cie
	i1_RGB_Scan_1.4.cht
	i1_RGB_Scan_1.4.ti2
	it8.cht
	linear.cal
	strange.cal
	3dap5k.sp
	CIE_C.sp
	D50_0.0.sp
	D50_0.1.sp
	D50_0.3.sp
	D50_0.5.sp
	D50_0.7.sp
	D50_1.0.sp
	D50_1.2.sp
	D50_1.5.sp
	D50_1.7.sp
	D50_2.0.sp
	D50_2.5.sp
	D50_3.0.sp
	GTIPlus.sp
	Office.sp
	SOtele.sp
	Trulux.sp
	TruluxPlus.sp
	example.sp
	example121.sp
